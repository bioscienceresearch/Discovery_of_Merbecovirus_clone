#workflow used
metaxa2 -1 1.fastq -2 2.fastq -o path_to/metaxa2/ -f p -d path_to/nt_database --cpu 16 --plus T --taxonomy T --table T --save_raw T --reltax T
path_to/bbmap/reformat.sh in=.extraction.fasta out=metaxa2_extraction.fq
megahit -r metaxa2_extraction.fq -o megahit_default -t 16
